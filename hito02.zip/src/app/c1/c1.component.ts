import { Component, OnInit } from '@angular/core';

import {Estrenos} from '../models/lista';

@Component({
  selector: 'app-c1',
  templateUrl: './c1.component.html',
  styleUrls: ['./c1.component.css']
})
export class C1Component implements OnInit {

  estrenosArray: Estrenos[] = [
    {name:"Malasaña", director:"Albert Pintó", img:"https://cinesteatrogoya.reservaentradas.com/cinesteatrogoya/obj/LCinesD_dat/eventos/JPG00044.jpg"},
    {name:"Fantasy Island", director:"Jeff Wadlow", img:"https://www.heraldo.es/ocio/sites/default/files/caratulafantasy.jpg"},
    {name:"1917", director:"Night Shyamalan", img:"https://lh3.googleusercontent.com/proxy/Q7dN_nSRTyThh-7eZwcWPvyIuWLXXX7pdcxop0_LxC4FaDDAfr7JcTS0xk-wqgq-l1FRC-QScGNk5l8cQ_K848C8Xk4of2n0yxvbHLQsTeG8hNbUX1RR-cBHedaMvPgEsrpG_0tM_0_oE8DRwA"},
    {name:"Aves de Presa", director:"Cathy Yan", img:"https://es.web.img3.acsta.net/pictures/19/12/11/18/10/4293997.jpg"},
    {name:"Dolittle", director:"Stephen Gaghan", img:"https://lh3.googleusercontent.com/proxy/r0KUgYDzHRiEn24u3rGDKUasO972UE3F_P6mr150IGiLf_X1OgA7Z-qqTFy0G6i34UXgWASXmtEY_r3c7-TQO0-1bVRvw3jPRH7R2cgjX3oMSSxKOdQwdiVmR25SEsYC-YUKqJQTioUh7eNj46Y8lb9VePb4XNfEzw"},
    {name:"Parásitos", director:"Boon Joon-Ho", img:"https://i.imgur.com/m5cb5j9.jpg"},
    {name:"Sonic, la película", director:"Jeff Fowler", img:"https://pics.filmaffinity.com/Sonic_la_pel_cula-730493692-mmed.jpg"},
  ];


  constructor() { }

  ngOnInit(): void {
  }

}


