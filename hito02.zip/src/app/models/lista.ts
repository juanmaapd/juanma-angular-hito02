export class Lista {
    id: number = 0;
    name: string;
    director: string;
    pais: string;
}

export class Estrenos {
    name: string;
    director: string;
    img: string;
}


