import { Lista } from './lista';

describe('Lista', () => {
  it('should create an instance', () => {
    expect(new Lista()).toBeTruthy();
  });
});
