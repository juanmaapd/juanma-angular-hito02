import { Component, OnInit } from '@angular/core';
import {Lista} from '../models/lista';

@Component({
  selector: 'app-c2',
  templateUrl: './c2.component.html',
  styleUrls: ['./c2.component.css']
})
export class C2Component implements OnInit {

  listaArray: Lista[] = [
    {id:1, name:"Toy Story 4", director:"Josh Cooley", pais:"EEUU"},
    {id:2, name:"Divergente", director:"Neil Burger", pais:"EEUU"},
    {id:3, name:"Glass", director:"Night Shyamalan", pais:"EEUU"},
    {id:3, name:"Contratiempo", director:"Oriol Paulo", pais:"España"}
  ];

  selectedLista: Lista = new Lista();

  openForEdit(lista: Lista) {
    this.selectedLista = lista;
  }

  addOrEdit(){
    if(this.selectedLista.id === 0) {
      this.selectedLista.id = this.listaArray.length + 1;
      this.listaArray.push(this.selectedLista);
    }

    this.selectedLista = new Lista();
  }

  delete() {
    if(confirm('¿Estás seguro de borrar la película?')){
      this.listaArray = this.listaArray.filter(x => x != this.selectedLista);
      this.selectedLista = new Lista();
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

}
